% Task5to6.m
o_img_1 = imread('IMG_07.jpg');
% I load that ground truth image
g_t_1 = imread('IMG_07_GT.png');
% I resize that ground truth pic to match the size of original pic
g_t_resize = imresize(g_t_1, size(o_img_1(:,:,1)));
o_img_2 = rgb2gray(o_img_1);
o_img_3 = imgaussfilt(o_img_2, 1); % to reduce noise i implement some properties gaussian
thresh_value = 2000;
e_img = edge(o_img_3, 'Canny');
d_img1 = imdilate(e_img, strel('disk', 2)); % to connect nearby areas,I dilute it and I used structuring element size 2
fimg1 = imfill(d_img1, 'holes');

% I recognize connected components here
conect_img = bwconncomp(fimg1);

% Then I filter all regions on the bases of size and shape
box = regionprops(conect_img, 'Area', 'BoundingBox');
v_reg = box([box.Area] > thresh_value);
for i = 1:length(v_reg)
    bound_box = v_reg(i).BoundingBox;
    rectangle('Position', bound_box, 'EdgeColor', 'r', 'LineWidth', 2);
end
subplot(1, 2, 1); imshow(o_img_1);
hold on;

for i = 1:length(v_reg)
    bound_box = v_reg(i).BoundingBox;
    rectangle('Position', bound_box, 'EdgeColor', 'r', 'LineWidth', 2);
end

hold off;
title('Segmentation Result');
subplot(1, 2, 2); imshow(g_t_resize); title('Ground Truth');
% I calculate these evaluation metrics according to your pdf 
b_seg1 = zeros(size(g_t_resize));
for i = 1:length(v_reg)
    bound_box = round(v_reg(i).BoundingBox);
    b_seg1(bound_box(2):(bound_box(2)+bound_box(4)-1), bound_box(1):(bound_box(1)+bound_box(3)-1)) = 1;
end
% I calculate Dice Score,Precisionand Recall
dicescore1 = 2 * sum(sum(g_t_resize & b_seg1)) / (sum(sum(g_t_resize)) + sum(sum(b_seg1)));
precise = sum(sum(g_t_resize & b_seg1)) / sum(sum(b_seg1));
recall1 = sum(sum(g_t_resize & b_seg1)) / sum(sum(g_t_resize));
% To display and record the results
fprintf('Dice Score: %.4f\n', dicescore1);
fprintf('Precision: %.4f\n', precise);
fprintf('Recall: %.4f\n', recall1);
% save the evaluation results to a file
eval_results = table(dicescore1, precise, recall1, 'VariableNames', {'DiceScore', 'Precision', 'Recall'});
writetable(eval_results, 'outputT6/evaluation_results.csv'); 

