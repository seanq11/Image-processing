%% Task-1
%Loading The Image
im=imread('IMG_01.jpg');

%Converting Orignal Image to GrayScale Image
im_gray=rgb2gray(im);

%Reducing the size of the image using Bilinear Interpolation
im_resized = imresize(im_gray, 0.5, 'bilinear'); % Resize the image

%Enhancing the image
im_enhanced=imadjust(im_gray);  %Contrast Adjustment
im_enhanced = medfilt2(im_enhanced, [1 1]);  %Median Filter To reduce Noise
im_enhanced = adapthisteq(im_enhanced);



%Binarization
im_b = ~imbinarize(im_enhanced,0.30);

figure;
subplot(1,3,1);imshow(im_resized);title('Resized Image')
subplot(1,3,2);imshow(im_enhanced);title('Enhanced Image')
subplot(1,3,3);imshow(im_b);title('Binarized Iamge')

%Histograms Before and After Enhancment
figure;

subplot(1,2,1);imhist(im_resized);title('Histogram Before Enhancement')
subplot(1,2,2);imhist(im_enhanced);title('Histogram After Enhancement')

%% Task-2
%Edge Detection Using Prewitt Edge Detector
im_edges = edge(im_gray, 'prewitt'); 
figure;
imshow(im_edges);title('Edge Detection')

%% Task-3
%Applying Different Morphological Operations
%Closing with line structural element
im_seg=imclose(im_edges,strel('line',5,1));

%Filling the Holes
im_seg=imfill(im_seg,'holes');

%Opening
im_seg=imopen(im_seg,strel(ones(1,1)));

%Delecting the Objects those not required
im_seg=bwareaopen(im_seg,1500);

%Dilating the Boundaries of the Objects
se = strel('disk',5);
im_seg=imdilate(im_seg,se);


figure; 
imshow(im_seg);title('Segmented Image')

%% Task-4
%Segmentation On the basis of Area

% Calculating the properties of connected components
stats = regionprops(im_seg, 'Area');

%Labeling the Objects
labeled_img = bwlabel(im_seg);

%For Washers
% Creating a mask for the Circles based on area thresholding Value
mask = ismember(labeled_img, find([stats.Area] <4000 ));

for i = 1:length(stats)
    % Check the area of the component
    area = stats(i).Area;
    
    % Differentiate based on area
    if area < 5000
        mask = mask + cat(3, 0, 0, 1) .* (im_seg == i);
    else 
        mask = mask + cat(3, 1, 0, 0).* (im_seg == i);
    end
end

im1=mask;

% Calculating the properties of connected components
stats = regionprops(im_seg, 'Area');

%For Screws
mask1 = ismember(labeled_img, find([stats.Area] >4000 ));

for i = 1:length(stats)
    % Check the area of the component
    area = stats(i).Area;
    
    % Differentiate based on area
    if area > 5000
        mask1 = mask1 + cat(3, 0, 0, 1) .* (im_seg == i);
    else
        mask1 = mask1 + cat(3, 1, 0, 0).* (im_seg == i);
    end
end

im2=mask1;

im_recognized=im1.*im2;
figure;
imshow(im_recognized);