% Task5-6
close, clc, close all
img = imread('IMG_07.jpg');
% I convert the img from rgb to grayscale
gimg = rgb2gray(img);
% to reduce noise i implement some properties
img_1 = imgaussfilt(gimg, 1);
thresh_value = 2000;
edgeimg_1 = edge(img_1, 'Canny');

% to connect nearby areas,I dilute it and I used structuring element size 2
dilate_edgeimg_1 = imdilate(edgeimg_1, strel('disk', 2)); 
filledimg_1 = imfill(dilate_edgeimg_1, 'holes');
% I recognize connected components here
conect_img = bwconncomp(filledimg_1);

% Then I filter all regions on the bases of size and shape
box = regionprops(conect_img, 'Area', 'BoundingBox');
v_reg = box([box.Area] > thresh_value);
figure;
imshow(img);
hold on;
for i = 1:length(v_reg)
    bound_box = v_reg(i).BoundingBox;
    rectangle('Position', bound_box, 'EdgeColor', 'r', 'LineWidth', 2);
end

hold off;
% To Save the result demand in your document
saveas(gcf, 'outputT5_6/result.png');



